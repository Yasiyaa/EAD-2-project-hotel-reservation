package com.example.usertype;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserTypeApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserTypeApplication.class, args);
	}

}
