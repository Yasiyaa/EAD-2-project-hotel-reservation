package com.example.usertype;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserTypeApplicationTests {

	@Test
	void contextLoads() {
	}

}
