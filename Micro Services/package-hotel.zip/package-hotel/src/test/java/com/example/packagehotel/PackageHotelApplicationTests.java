package com.example.packagehotel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PackageHotelApplicationTests {

	@Test
	void contextLoads() {
	}

}
