package com.example.packagehotel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PackageHotelApplication {

	public static void main(String[] args) {
		SpringApplication.run(PackageHotelApplication.class, args);
	}

}
